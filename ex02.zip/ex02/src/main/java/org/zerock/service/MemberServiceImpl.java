package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zerock.domain.BoardVO;
import org.zerock.domain.MemberVO;
import org.zerock.mapper.MemberMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class MemberServiceImpl implements MemberService {
	@Setter(onMethod_ = @Autowired) 
private MemberMapper mapper;
 @Override
 public void register(MemberVO member) {
	 log.info("reguster....."+member);
	 
	 mapper.insert(member);
 }
 	
	public MemberVO get(String id) {
		log.info("getList ..............");
		return mapper.read(id);
		
	};

	public boolean modify(MemberVO member) {
		log.info("modify..............."+member);
		return mapper.update(member) == 1;
		
	};
	public boolean remove(String id) {
		log.info("modify..............."+id);
		return mapper.delete(id) == 1;
		
	};
	public List<MemberVO> getList(){
		
		log.info("getList..................");
		
		return mapper.getList();
		
	};
}
