package org.zerock.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;
import org.zerock.domain.MemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
// Java Config
// @ContextConfiguration(classes = {org.zerock.config.RootConfig.class} )
@Log4j
public class MemberMapperTests {
	@Setter(onMethod_ = @Autowired)
	private MemberMapper mapper;

	@Test
	public void testGetList() {
		
		mapper.getList().forEach(board -> log.info(board));

	}
	@Test
	public void testInsert() { 
		MemberVO member = new MemberVO();
		member.setId("pj");
		member.setPassword("내용5");
		member.setName("작성자5");
		member.setPhone("안녕");
		mapper.insert(member);
		
		log.info(member);
	}
	@Test
	public void testRead() {
		MemberVO member = mapper.read("sd");
		log.info(member);
	}
	@Test
	public void testDelete() {
		log.info("DELETE COUNT: " + mapper.delete("id"));
	}
	@Test
	public void testUpdate() {
		MemberVO member = new MemberVO();
		member.setId("dj");
		member.setPassword("제목22");
		member.setName("내용2");
		member.setPhone("작성자2");
	
		int count = mapper.update(member);
		log.info("UPDATE COUNT:"+count);
	}
	
}
